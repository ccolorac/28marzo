package programapitagoras;

public class Pitagoras 
{
    static public double Calcular_Hipotenusa(double a, double b)
    {
        return Math.sqrt((Math.pow(a, 2)+ Math.pow(b, 2)));
    }
}
